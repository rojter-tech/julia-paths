somevar = 10
