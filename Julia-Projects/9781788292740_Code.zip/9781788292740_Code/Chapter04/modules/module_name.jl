function myname()
  MY_NAME
end
